package com.Bai8_Muc5.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Bai8_Muc5.entity.Product;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface ProductRepository extends JpaRepository<Product, Long> {

    List<Product> findAllByOrderByPriceAsc();

    List<Product> findAllByCategoryId(Long categoryId);

    List<Product> findByNameContainingIgnoreCase(String keyword);
    
    Page<Product> findByNameContainingIgnoreCase(String keyword, Pageable pageable);
}