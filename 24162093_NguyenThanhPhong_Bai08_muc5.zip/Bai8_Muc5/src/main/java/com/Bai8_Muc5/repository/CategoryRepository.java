package com.Bai8_Muc5.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import com.Bai8_Muc5.entity.Category;

public interface CategoryRepository extends JpaRepository<Category, Long> {

    List<Category> findByNameContainingIgnoreCase(String keyword);

    Page<Category> findByNameContainingIgnoreCase(
            String keyword,
            Pageable pageable
    );
}