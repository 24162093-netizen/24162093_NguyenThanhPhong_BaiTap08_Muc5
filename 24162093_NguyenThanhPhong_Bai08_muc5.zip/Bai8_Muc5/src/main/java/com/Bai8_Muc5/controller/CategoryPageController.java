package com.Bai8_Muc5.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class CategoryPageController {

    @GetMapping("/categories")
    public String categories() {
        return "category";
    }
}