package com.Bai8_Muc5.controller;

import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestParam;
import com.Bai8_Muc5.entity.Category;
import com.Bai8_Muc5.service.CategoryService;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/categories")
@RequiredArgsConstructor
public class CategoryRestController {

    private final CategoryService categoryService;

    // GET: lấy tất cả category
    @GetMapping
    public List<Category> getAll() {
        return categoryService.findAll();
    }

    // GET: lấy category theo id
    @GetMapping("/{id}")
    public Category getById(@PathVariable Long id) {
        return categoryService.findById(id);
    }

    // POST: thêm category
    @PostMapping
    public Category create(@RequestBody Category category) {
        category.setId(null);
        return categoryService.save(category);
    }

    // PUT: cập nhật category
    @PutMapping("/{id}")
    public Category update(
            @PathVariable Long id,
            @RequestBody Category category) {

        Category existing = categoryService.findById(id);

        if (existing == null) {
            return null;
        }

        existing.setName(category.getName());
        existing.setIcon(category.getIcon());

        return categoryService.save(existing);
    }

    // DELETE: xóa category
    @DeleteMapping("/{id}")
    public Boolean delete(@PathVariable Long id) {

        Category existing = categoryService.findById(id);

        if (existing == null) {
            return false;
        }

        categoryService.deleteById(id);
        return true;
    }
    
    @GetMapping("/search")
    public List<Category> searchCategories(
            @RequestParam(defaultValue = "") String keyword) {

        return categoryService.search(keyword);
    }
    
    @GetMapping("/search-page")
    public Page<Category> searchCategoriesPage(
            @RequestParam(defaultValue = "") String keyword,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "3") int size) {

        return categoryService.search(
                keyword,
                PageRequest.of(page, size)
        );
    }
}