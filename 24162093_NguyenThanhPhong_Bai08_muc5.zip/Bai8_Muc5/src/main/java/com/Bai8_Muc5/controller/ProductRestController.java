package com.Bai8_Muc5.controller;

import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Bai8_Muc5.entity.Category;
import com.Bai8_Muc5.entity.Product;
import com.Bai8_Muc5.service.CategoryService;
import com.Bai8_Muc5.service.ProductService;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.web.bind.annotation.RequestParam;

import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.RequestParam;
@RestController
@RequestMapping("/api/products")
@RequiredArgsConstructor
public class ProductRestController {

    private final ProductService productService;
    private final CategoryService categoryService;

    // GET: lấy tất cả product
    @GetMapping
    public List<Product> getAll() {
        return productService.findAll();
    }

    // GET: lấy product theo id
    @GetMapping("/{id}")
    public Product getById(@PathVariable Long id) {
        return productService.findById(id);
    }

    // POST: thêm product
    @PostMapping
    public Product create(@RequestBody Product product) {

        product.setId(null);

        if (product.getCategory() != null
                && product.getCategory().getId() != null) {

            Category category = categoryService.findById(
                    product.getCategory().getId()
            );

            product.setCategory(category);
        }

        return productService.save(product);
    }

    // PUT: cập nhật product
    @PutMapping("/{id}")
    public Product update(
            @PathVariable Long id,
            @RequestBody Product product) {

        Product existing = productService.findById(id);

        if (existing == null) {
            return null;
        }

        existing.setName(product.getName());
        existing.setPrice(product.getPrice());
        existing.setQuantity(product.getQuantity());
        existing.setDescription(product.getDescription());
        existing.setImage(product.getImage());

        if (product.getCategory() != null
                && product.getCategory().getId() != null) {

            Category category = categoryService.findById(
                    product.getCategory().getId()
            );

            existing.setCategory(category);

        } else {
            existing.setCategory(null);
        }

        return productService.save(existing);
    }

    // DELETE: xóa product
    @DeleteMapping("/{id}")
    public Boolean delete(@PathVariable Long id) {

        Product existing = productService.findById(id);

        if (existing == null) {
            return false;
        }

        productService.deleteById(id);

        return true;
    }
    
    @GetMapping("/price-asc")
    public List<Product> getProductsByPriceAsc() {
        return productService.findAllByPriceAsc();
    }
    
    @GetMapping("/category/{categoryId}")
    public List<Product> getProductsByCategory(
            @PathVariable Long categoryId) {

        return productService.findAllByCategoryId(categoryId);
    }
    
    @GetMapping("/search")
    public List<Product> searchProducts(
            @RequestParam(defaultValue = "") String keyword) {

        return productService.search(keyword);
    }
    
    @GetMapping("/search-page")
    public Page<Product> searchProductsPage(
            @RequestParam(defaultValue = "") String keyword,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "3") int size) {

        return productService.search(
                keyword,
                PageRequest.of(page, size)
        );
    }
}