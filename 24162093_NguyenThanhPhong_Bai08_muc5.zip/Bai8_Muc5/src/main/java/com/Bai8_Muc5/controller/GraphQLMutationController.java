package com.Bai8_Muc5.controller;

import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.stereotype.Controller;

import com.Bai8_Muc5.entity.Category;
import com.Bai8_Muc5.entity.Product;
import com.Bai8_Muc5.service.CategoryService;
import com.Bai8_Muc5.service.ProductService;

import lombok.RequiredArgsConstructor;

@Controller
@RequiredArgsConstructor
public class GraphQLMutationController {

    private final CategoryService categoryService;
    private final ProductService productService;

    @MutationMapping
    public Category createCategory(
            @Argument String name,
            @Argument String icon) {

        Category category = new Category();
        category.setName(name);
        category.setIcon(icon);

        return categoryService.save(category);
    }
    
    @MutationMapping
    public Category updateCategory(
            @Argument Long id,
            @Argument String name,
            @Argument String icon) {

        Category category = categoryService.findById(id);

        if (category == null) {
            return null;
        }

        category.setName(name);
        category.setIcon(icon);

        return categoryService.save(category);
    }
    
    @MutationMapping
    public Boolean deleteCategory(@Argument Long id) {

        Category category = categoryService.findById(id);

        if (category == null) {
            return false;
        }

        categoryService.deleteById(id);
        return true;
    }
    
    @MutationMapping
    public Product createProduct(
            @Argument String name,
            @Argument Double price,
            @Argument Integer quantity,
            @Argument String description,
            @Argument String image,
            @Argument Long categoryId) {

        Product product = new Product();

        product.setName(name);
        product.setPrice(price);
        product.setQuantity(quantity);
        product.setDescription(description);
        product.setImage(image);

        if (categoryId != null) {
            Category category = categoryService.findById(categoryId);
            product.setCategory(category);
        }

        return productService.save(product);
    }
    
    @MutationMapping
    public Product updateProduct(
            @Argument Long id,
            @Argument String name,
            @Argument Double price,
            @Argument Integer quantity,
            @Argument String description,
            @Argument String image,
            @Argument Long categoryId) {

        Product product = productService.findById(id);

        if (product == null) {
            return null;
        }

        product.setName(name);
        product.setPrice(price);
        product.setQuantity(quantity);
        product.setDescription(description);
        product.setImage(image);

        if (categoryId != null) {
            Category category = categoryService.findById(categoryId);
            product.setCategory(category);
        } else {
            product.setCategory(null);
        }

        return productService.save(product);
    }
    
    @MutationMapping
    public Boolean deleteProduct(@Argument Long id) {

        Product product = productService.findById(id);

        if (product == null) {
            return false;
        }

        productService.deleteById(id);
        return true;
    }
}