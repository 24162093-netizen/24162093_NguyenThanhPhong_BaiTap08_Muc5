package com.Bai8_Muc5.controller;

import java.util.List;

import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;

import com.Bai8_Muc5.entity.Category;
import com.Bai8_Muc5.entity.Product;
import com.Bai8_Muc5.service.CategoryService;
import com.Bai8_Muc5.service.ProductService;

import lombok.RequiredArgsConstructor;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import com.Bai8_Muc5.graphql.ProductPage;
import com.Bai8_Muc5.graphql.CategoryPage;
@Controller
@RequiredArgsConstructor
public class GraphQLQueryController {

    private final CategoryService categoryService;
    private final ProductService productService;

    // =========================
    // CATEGORY
    // =========================

    @QueryMapping
    public List<Category> categories() {
        return categoryService.findAll();
    }

    @QueryMapping
    public Category category(@Argument Long id) {
        return categoryService.findById(id);
    }
    
    @QueryMapping
    public List<Category> searchCategories(@Argument String keyword) {
        return categoryService.search(keyword);
    }

    // =========================
    // PRODUCT
    // =========================

    @QueryMapping
    public List<Product> products() {
        return productService.findAll();
    }

    @QueryMapping
    public List<Product> productsByPriceAsc() {
        return productService.findAllByPriceAsc();
    }
    
    @QueryMapping
    public List<Product> productsByCategory(@Argument Long categoryId) {
        return productService.findAllByCategoryId(categoryId);
    }
    
    @QueryMapping
    public List<Product> searchProducts(@Argument String keyword) {
        return productService.search(keyword);
    }
    
    @QueryMapping
    public Product product(@Argument Long id) {
        return productService.findById(id);
    }
    
    @QueryMapping
    public ProductPage searchProductsPage(
            @Argument String keyword,
            @Argument int page,
            @Argument int size) {

        Page<Product> result = productService.search(
                keyword,
                PageRequest.of(page, size)
        );

        return new ProductPage(
                result.getContent(),
                result.getTotalElements(),
                result.getTotalPages(),
                result.getNumber(),
                result.getSize()
        );
    }
    
    @QueryMapping
    public CategoryPage searchCategoriesPage(
            @Argument String keyword,
            @Argument int page,
            @Argument int size) {

        Page<Category> result = categoryService.search(
                keyword,
                PageRequest.of(page, size)
        );

        return new CategoryPage(
                result.getContent(),
                result.getTotalElements(),
                result.getTotalPages(),
                result.getNumber(),
                result.getSize()
        );
    }
}