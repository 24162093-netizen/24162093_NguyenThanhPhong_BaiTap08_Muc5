package com.Bai8_Muc5.graphql;

import java.util.List;

import com.Bai8_Muc5.entity.Category;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class CategoryPage {

    private List<Category> content;

    private long totalElements;

    private int totalPages;

    private int page;

    private int size;
}