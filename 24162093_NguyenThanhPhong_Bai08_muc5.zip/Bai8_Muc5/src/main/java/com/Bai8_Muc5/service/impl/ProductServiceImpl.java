package com.Bai8_Muc5.service.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.Bai8_Muc5.entity.Product;
import com.Bai8_Muc5.repository.ProductRepository;
import com.Bai8_Muc5.service.ProductService;

import lombok.RequiredArgsConstructor;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

@Service
@RequiredArgsConstructor
public class ProductServiceImpl implements ProductService {

	private final ProductRepository productRepository;

	@Override
	public List<Product> findAll() {
		return productRepository.findAll();
	}

	@Override
	public List<Product> findAllByPriceAsc() {
		return productRepository.findAllByOrderByPriceAsc();
	}

	@Override
	public List<Product> search(String keyword) {
	    return productRepository.findByNameContainingIgnoreCase(keyword);
	}
	
	@Override
	public Page<Product> search(String keyword, Pageable pageable) {
	    return productRepository.findByNameContainingIgnoreCase(keyword, pageable);
	}
	
	@Override
	public List<Product> findAllByCategoryId(Long categoryId) {
		return productRepository.findAllByCategoryId(categoryId);
	}

	@Override
	public Product findById(Long id) {
		return productRepository.findById(id).orElse(null);
	}

	@Override
	public Product save(Product product) {
		return productRepository.save(product);
	}

	@Override
	public void deleteById(Long id) {
		productRepository.deleteById(id);
	}
}