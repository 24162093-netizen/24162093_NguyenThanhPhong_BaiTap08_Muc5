package com.Bai8_Muc5.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.Bai8_Muc5.entity.Category;

public interface CategoryService {

    List<Category> findAll();

    Category findById(Long id);

    List<Category> search(String keyword);

    Page<Category> search(String keyword, Pageable pageable);

    Category save(Category category);

    void deleteById(Long id);
}