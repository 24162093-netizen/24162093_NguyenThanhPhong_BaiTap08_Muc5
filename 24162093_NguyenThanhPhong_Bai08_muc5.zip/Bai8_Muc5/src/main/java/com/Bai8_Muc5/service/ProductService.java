package com.Bai8_Muc5.service;

import java.util.List;

import com.Bai8_Muc5.entity.Product;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface ProductService {

    List<Product> findAll();

    List<Product> findAllByPriceAsc();

    List<Product> findAllByCategoryId(Long categoryId);

    List<Product> search(String keyword);

    Product findById(Long id);

    Product save(Product product);

    void deleteById(Long id);
    
    Page<Product> search(String keyword, Pageable pageable);
}