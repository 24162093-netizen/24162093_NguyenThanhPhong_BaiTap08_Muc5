package com.Bai8_Muc5;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Bai8Muc5ApplicationTests {

	@Test
	void contextLoads() {
	}

}
